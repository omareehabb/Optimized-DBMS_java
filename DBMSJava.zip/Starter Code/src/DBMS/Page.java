package DBMS;

import java.io.Serializable;
import java.util.ArrayList;

public class Page implements Serializable {
    private static final long serialVersionUID = 1L; //Serializable, converted to a byte stream ->useful for saving and loading from memory or file.
    public ArrayList<String[]> records;
    public int pageNumber;
    
    public Page(int pageNumber) {
        this.pageNumber = pageNumber;
        this.records = new ArrayList<>();
    }
    
    public boolean isFull(int pageSize) {
        return records.size() >= pageSize;
    }
    
    public void addRecord(String[] record) {
        records.add(record);
    }
}