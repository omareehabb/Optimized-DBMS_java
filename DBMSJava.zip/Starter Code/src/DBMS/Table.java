package DBMS;

import java.io.Serializable;
import java.util.ArrayList;

public class Table implements Serializable {
    private static final long serialVersionUID = 1L;//1 is just the version number assigning.
                                                    //The L at the end makes it a long literal.
    public String tableName;
    public String[] columnsNames;
    public ArrayList<Integer> pageNumbers;
    public ArrayList<String> traceLog;
    
    public Table(String tableName, String[] columnsNames) {
        this.tableName = tableName;
        this.columnsNames = columnsNames;
        this.pageNumbers = new ArrayList<>();
        this.traceLog = new ArrayList<>();
    }
    
    public void addToTrace(String operation) {
        traceLog.add(operation);
    }
    
    public String getFullTrace() {
        return String.join("\n", traceLog);
    }
    
    public String getLastTrace() {
        return traceLog.isEmpty() ? "" : traceLog.get(traceLog.size() - 1);
    }
}
