package DBMS;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import org.junit.Test;

public class DBApp {
    static int dataPageSize = 30;  //tested using 2,20,30 and 50 
    
    public static void createTable(String tableName, String[] columnsNames) {
        Table table = new Table(tableName, columnsNames);
        FileManager.storeTable(tableName, table);
        
        // Add to trace
        String traceEntry = String.format("Table created name:%s, columnsNames:%s", 
            tableName, Arrays.toString(columnsNames));
        table.addToTrace(traceEntry);
        FileManager.storeTable(tableName, table);
        //why storeTable again?? ->This is done because the table object was modified (trace updated),
        //so we re-save it to ensure the changes are preserved.
    }
    
    public static void insert(String tableName, String[] record) {
        long startTime = System.currentTimeMillis();
        
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            throw new IllegalArgumentException("Table does not exist: " + tableName);
        }
        
        // Find the last page or create a new one if full
        Page page = null;
        int pageNumber = table.pageNumbers.isEmpty() ? 0 : table.pageNumbers.get(table.pageNumbers.size() - 1);
        //existing pages?  -Load the last page.  If that page is full, increment the page number and create a new page.
        if (!table.pageNumbers.isEmpty()) {
            page = FileManager.loadTablePage(tableName, pageNumber);
            if (page.isFull(dataPageSize)) {
                pageNumber++;
                page = new Page(pageNumber);
            }
        } else { //no pages exist? just create the first page.

            page = new Page(pageNumber);
        }
        
        // Add record to page
        page.addRecord(record);
        
        // Update page numbers list if this is a new page
        if (table.pageNumbers.isEmpty() || pageNumber > table.pageNumbers.get(table.pageNumbers.size() - 1)) {
            table.pageNumbers.add(pageNumber);
        }
        
        // Store the updated page and table
        FileManager.storeTablePage(tableName, pageNumber, page);
        
        // Add to trace
        long executionTime = System.currentTimeMillis() - startTime;
        String traceEntry = String.format("Inserted:%s, at page number:%d, execution time (mil):%d", 
            Arrays.toString(record), pageNumber, executionTime);
        table.addToTrace(traceEntry);
        FileManager.storeTable(tableName, table);
    }

    // (3) selects depending on parameters
    public static ArrayList<String[]> select(String tableName) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            throw new IllegalArgumentException("Table does not exist: " + tableName);
        }
        
        ArrayList<String[]> result = new ArrayList<>();
        for (int pageNumber : table.pageNumbers) {
            Page page = FileManager.loadTablePage(tableName, pageNumber);
            result.addAll(page.records);
        }
        
        // Add to trace
        long executionTime = System.currentTimeMillis() - startTime;
        String traceEntry = String.format("Select all pages:%d, records:%d, execution time (mil):%d", 
            table.pageNumbers.size(), result.size(), executionTime);
        table.addToTrace(traceEntry);
        FileManager.storeTable(tableName, table);
        
        return result;
    }
    
    public static ArrayList<String[]> select(String tableName, int pageNumber, int recordNumber) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            throw new IllegalArgumentException("Table does not exist: " + tableName);
        }
        
        // Convert to 0-based index if needed (compatibility with test cases)
        // pageNumber = pageNumber; // Keep as is for 0-based
        
        if (pageNumber < 0 || pageNumber >= table.pageNumbers.size()) {
            throw new IllegalArgumentException("Invalid page number: " + pageNumber + 
                ". Valid pages are 0 to " + (table.pageNumbers.size() - 1));
        }
        
        int actualPageNum = table.pageNumbers.get(pageNumber);
        Page page = FileManager.loadTablePage(tableName, actualPageNum);
        
        if (recordNumber < 0 || recordNumber >= page.records.size()) {
            throw new IllegalArgumentException("Invalid record number: " + recordNumber + 
                ". Valid records are 0 to " + (page.records.size() - 1));
        }
        
        ArrayList<String[]> result = new ArrayList<>();
        result.add(page.records.get(recordNumber));
        
        // Add to trace
        long executionTime = System.currentTimeMillis() - startTime;
        String traceEntry = String.format("Select pointer page:%d, record:%d, total output count:1, execution time (mil):%d", 
            pageNumber, recordNumber, executionTime);
        table.addToTrace(traceEntry);
        FileManager.storeTable(tableName, table);
        
        return result;
    }    

    public static ArrayList<String[]> select(String tableName, String[] cols, String[] vals) {
        long startTime = System.currentTimeMillis();
        if (cols.length != vals.length) {
            throw new IllegalArgumentException("Columns and values arrays must be of same length");
        }
        
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            throw new IllegalArgumentException("Table does not exist: " + tableName);
        }
        
        ArrayList<String[]> result = new ArrayList<>();
        ArrayList<String> pagesCounts = new ArrayList<>();
        
        for (int pageNumber : table.pageNumbers) {
            Page page = FileManager.loadTablePage(tableName, pageNumber);
            int matchesInPage = 0;
            
            for (String[] record : page.records) {
                boolean match = true;
                for (int i = 0; i < cols.length; i++) {
                    int colIndex = Arrays.asList(table.columnsNames).indexOf(cols[i]);
                    if (colIndex == -1 || !record[colIndex].equals(vals[i])) {
                        match = false;
                        break;
                    }
                }
                
                if (match) {
                    result.add(record);
                    matchesInPage++;
                }
            }
            
            if (matchesInPage > 0) {
                pagesCounts.add(String.format("[%d, %d]", pageNumber, matchesInPage));
            }
        }
        
        // Add to trace
        long executionTime = System.currentTimeMillis() - startTime;
        String traceEntry = String.format("Select condition:%s->%s, Records per page:%s, records:%d, execution time (mil):%d", 
            Arrays.toString(cols), Arrays.toString(vals), pagesCounts.toString(), result.size(), executionTime);
        table.addToTrace(traceEntry);
        FileManager.storeTable(tableName, table);
        
        return result;
    }
    
    public static String getFullTrace(String tableName) {
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            throw new IllegalArgumentException("Table does not exist: " + tableName);
        }
        
        // Add pages and records count to the trace
        String countEntry = String.format("Pages Count: %d, Records Count: %d", 
            table.pageNumbers.size(), 
            table.pageNumbers.stream()
                .mapToInt(pageNum -> FileManager.loadTablePage(tableName, pageNum).records.size())
                .sum());
        
        return table.getFullTrace() + "\n" + countEntry;
    }
    
    public static String getLastTrace(String tableName) {
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            throw new IllegalArgumentException("Table does not exist: " + tableName);
        }
        return table.getLastTrace();
    }
    
    public static void main(String []args) throws IOException 
    { 
      
     String[] cols = {"id","name","major","semester","gpa"}; 
     createTable("student", cols); 
     String[] r1 = {"1", "stud1", "CS", "5", "0.9"}; 
     insert("student", r1); 
      
     String[] r2 = {"2", "stud2", "BI", "7", "1.2"}; 
     insert("student", r2); 
      
     String[] r3 = {"3", "stud3", "CS", "2", "2.4"}; 
     insert("student", r3); 
      
     String[] r4 = {"4", "stud4", "DMET", "9", "1.2"}; 
     insert("student", r4); 
      
     String[] r5 = {"5", "stud5", "BI", "4", "3.5"}; 
     insert("student", r5); 
      
      
           System.out.println("Output of selecting the whole table content:"); 
     ArrayList<String[]> result1 = select("student"); 
           for (String[] array : result1) { 
               for (String str : array) { 
                   System.out.print(str + " "); 
               } 
               System.out.println(); 
           } 
            
           System.out.println("--------------------------------"); 
           System.out.println("Output of selecting the output by position:"); 
     ArrayList<String[]> result2 = select("student", 1, 1); 
           for (String[] array : result2) { 
               for (String str : array) { 
                   System.out.print(str + " "); 
               } 
               System.out.println();  
           } 
            
           System.out.println("--------------------------------"); 
           System.out.println("Output of selecting the output by column condition:"); 
     ArrayList<String[]> result3 = select("student", new String[]{"gpa"}, new 
   String[]{"1.2"}); 
           for (String[] array : result3) { 
    
    
               for (String str : array) { 
                   System.out.print(str + " "); 
               } 
               System.out.println();  
           } 
           System.out.println("--------------------------------"); 
     System.out.println("Full Trace of the table:"); 
     System.out.println(getFullTrace("student")); 
     System.out.println("--------------------------------"); 
     System.out.println("Last Trace of the table:"); 
     System.out.println(getLastTrace("student")); 
     System.out.println("--------------------------------"); 
     System.out.println("The trace of the Tables Folder:"); 
     System.out.println(FileManager.trace()); 
     FileManager.reset(); 
     System.out.println("--------------------------------"); 
     System.out.println("The trace of the Tables Folder after resetting:"); 
     System.out.println(FileManager.trace());
     
     //////////////////////////// reset ////////////////////////////
     System.out.println("--------------------------------"); 
     System.out.println("The trace of the Tables Folder:");
     System.out.println(FileManager.trace());

     FileManager.reset();  // <-- RESET HERE

     System.out.println("--------------------------------"); 
     System.out.println("The trace of the Tables Folder after resetting:");
     System.out.println(FileManager.trace());
      
    }

}
